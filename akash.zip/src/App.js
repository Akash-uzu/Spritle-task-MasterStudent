import React from 'react';

// pages

import Login from './pages/login/login';
import Signup from './pages/signup/signup';
import Home from './pages/home/home';

// react router
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Dashboard from './pages/dashboard/dashboard';
import MyToast from './components/tostify/tostify';
import Master from './pages/dashboard/master';
import StudentPage from './pages/dashboard/student';

function App() {
  return (
    <>
  <BrowserRouter>
    <Routes>
      <Route path='/' element={<Home />} />
      <Route path='/login' element={<Login />} /> 
      <Route path='/signup' element={<Signup />} />
      <Route path='/dashboard' element={<Dashboard />} />
      <Route path='/master' element={<Master/>}></Route>
      <Route path='/student' element={<StudentPage/>}></Route>
    </Routes>
  </BrowserRouter>
  <MyToast />
    </>
  );
}

export default App;
