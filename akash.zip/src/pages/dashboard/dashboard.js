import React, { useEffect, useState } from "react";
import Master from "./master";
import Student from "./student";

export default function Dashboard(){

    // hooks
    const [userRole,setUserRole] = useState(false)

    useEffect(() => {
        const credientials = localStorage.getItem("credientials");
        console.log(credientials)
        if(credientials.role){
            if(credientials.role === "Master"){
                setUserRole(true)
            }
            if(credientials.role === "Student"){
                setUserRole(false)
            }   
        }else{
            window.location.href="/login"
        }
    },[])

    return(
        <>
        <span>welcome</span>

        {
            userRole ? <Master/> : <Student />
        }

        </>
    )
}