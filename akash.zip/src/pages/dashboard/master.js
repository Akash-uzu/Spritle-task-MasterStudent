import React, { useState } from "react";
const {
  zero,
  one,
  two,
  three,
  four,
  five,
  six,
  seven,
  eight,
  nine,
  plus,
  minus,
  times,
  divided_by,
} = require("../../calculations/Calculations.js");

function MastersPage() {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [activityLog, setActivityLog] = useState([]);

  const handleInputChange = (e) => {
    setInput(e.target.value);
  };

  

  const handleSubmit = (e) => {
    e.preventDefault();
    // Perform the calculation
    const value = () => {
      return eval(input);
    };
    let result = value();
    console.log(result);

    setOutput(result);
    setActivityLog([...activityLog, { input, output: result }]);
    JSON.parse(localStorage.setItem("activitylog",activityLog))
    setInput("");
  };

  return (
    <div>
      <h2>Master's Page</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" value={input} onChange={handleInputChange} />
        <button type="submit">Calculate</button>
      </form>
      <h3>Output: {output}</h3>
      <h3>Activity Log:</h3>
      <ul>
        {activityLog.map((item, index) => (
          <li key={index}>
            Input: {item.input} - Output: {item.output}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default MastersPage;
