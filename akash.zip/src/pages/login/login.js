import React, { useState } from "react";
import { toast, ToastContainer } from "react-toastify";
import { emailRegex } from "../utli/regex";

// css
import "./login.css";
import "react-toastify/dist/ReactToastify.css";
import MyToast, { toastMessage } from "../../components/tostify/tostify";

export default function Login() {
  // hooks
  const [loginData, setLoginData] = useState({
    email: "",
    password: "",
  });

  const [emailError, setemailError] = useState("");
  const [passwordError, setPasswordError] = useState("");

  const loginHandler = (event) => {
    const data = { ...loginData };
    data[event.target.id] = event.target.value;
    setLoginData(data);
  };

  const submit = () => {
    if (loginData.email.match(emailRegex)) {
      setemailError("");
    } else {
      setemailError("Invalid Email");
    }

    if (loginData.password == "") {
      setPasswordError("Enter password");
    } else {
      setPasswordError("");
    }

    if (loginData.email.match(emailRegex) && loginData.password != "") {
      proceedLogin();
    }
  };

  const proceedLogin = () => {
    const crediential = JSON.parse(localStorage.getItem("credientials"));

    if (crediential) {
      if (
        loginData.email == crediential.email &&
        loginData.password == crediential.password
      ) {
        localStorage.setItem("role", crediential.role);
        window.location.href = "/dashboard";
      } else {
        toastMessage("error", "Incorrect password! try again.");
      }
    } else {
      toastMessage("error", "user do not exist");
    }
  };

  return (
    <>
      <div className="main-container">
        <div className="main-login-heading">
          <h2>Login Page</h2>
        </div>
        <div className="login-container">
          <input
            type="email"
            id="email"
            placeholder="Email"
            onChange={loginHandler}
          />
          <span>{emailError}</span>
          <input
            type="password"
            id="password"
            placeholder="Password"
            onChange={loginHandler}
          />
          <span>{passwordError}</span>
          <button className="login-Button" onClick={submit}>
            Login
          </button>
        </div>
      </div>
    </>
  );
}

<ToastContainer
  position="top-right"
  autoClose={5000}
  hideProgressBar={false}
  newestOnTop={false}
  closeOnClick
  rtl={false}
  pauseOnFocusLoss
  draggable
  pauseOnHover
  theme="light"
/>;
{
  /* Same as */
}
<ToastContainer />;
