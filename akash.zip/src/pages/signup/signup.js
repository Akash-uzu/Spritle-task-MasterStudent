import React, { useState } from "react";
import { toastMessage } from "../../components/tostify/tostify";
import { emailRegex } from "../utli/regex";

// css
import './signup.css';


export default function Signup(){

    const [signupData,setSignupData] = useState({
        name:'',
        email:'',
        role:'Master',
        password:'',
        confirmPassword:''
    })

    const signupHandler = (event) => {
        const data = {...signupData};
        data[event.target.id] = event.target.value;
        setSignupData(data)
    }
    const allDatas = []
    allDatas.push(JSON.parse(localStorage.getItem("credientials")))
    console.log(allDatas)

    // error handeling hooks
    const [nameError,setNameError] = useState('')
    const [emailError,setEmailError] = useState('')
    const [passwordError,setPasswordError] = useState('')
    const [confirmPassword,setConfirmPassword] = useState('')
    const [notMatched,setNotMatched] = useState('')
    

    const signup = () => {
        
        if(signupData.email.match(emailRegex)){
            setEmailError("")
        }else{
            setEmailError("Invalid Email")
        }

        if(signupData.name === ""){
            setNameError("Enter Your Name")
        }else{
            setNameError("")
        }

        if(signupData.password === ""){
            setPasswordError("Enter Password")
        }else{
            setPasswordError("")
        }

        if(signupData.password !== signupData.confirmPassword){
            setNotMatched("Password should be same")
        }else if(signupData.confirmPassword === ""){
            setNotMatched("Enter confirm password")
        }else{
            setNotMatched("")
        }

        if(signupData.email.match(emailRegex) && signupData.name !== "" && signupData.password !== "" && signupData.password === signupData.confirmPassword && signupData.password !=="" && signupData.confirmPassword !==""){
            console.log(signupData)
/
            proceedSignup()
        }
    }

    const proceedSignup = () => {
      localStorage.setItem("credientials",JSON.stringify(allDatas.push(signupData)))

      toastMessage("success","signup successfull");
        setTimeout(() => {
            window.location.href="/login"
        },3000)
    }

    return(
        <>
        <div className="main-container">
            <div className="main-signup-heading">
                <h2>
                Signup Page
                    </h2>
            </div>
        <div className="signup-container">
        <input type="text" id="name" onChange={signupHandler} placeholder="name" />
        <span>{nameError}</span>
        <input type="email" id="email" onChange={signupHandler} placeholder="Email" />
        <span>{emailError}</span>
        <select id="role" onChange={signupHandler}>
            <option value="Master">Master</option>
            <option value="Student">Student</option>
        </select>
        <input type="password" id="password" onChange={signupHandler} placeholder="Password"  />
        <span>{passwordError}</span>
        <input type="password" id="confirmPassword" onChange={signupHandler} placeholder="Confirm Password"/>
        <span>{confirmPassword}{notMatched}</span>
        
        <button className="signup-Button" onClick={signup}>Signup</button>
        </div>
        </div>
        </>
    )
}

